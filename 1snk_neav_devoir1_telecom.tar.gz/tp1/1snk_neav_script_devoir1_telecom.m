close all;
clear all;

% Constantes du TP
Fe = 24000; % fréquence d'échantillonnage Fe = 24 000 Hz
Te = 1/Fe; % période d'échantillonnage en s
Rb = 6000; % débit binaire Rb = 6 000 bits/s
Tb = 1/Rb; 



% Nombre de bits
N = 1024;

% échelle fréquentielle
p2 = 8192;
fp2 = linspace(0, Fe, p2);

% Génération d'une suite de bits
alea = randi([0,1],1,N);

%% Modulateur 1


% Mapping : 1 -> 1 | 0 -> -1
indices1 = find(alea == 0);
alea1 = alea;
alea1(indices1) = alea1(indices1) - 1;


% Suréchantillonnage 
Ts1 = 1/Rb;
Ns1 = floor(Ts1/Te);
alea1 = [ alea1 ; zeros(Ns1 -1,N) ];
alea1 = alea1(:);
alea1 = alea1';


% Filtre
h1 = ones(1, Ns1);
alea1_filtre = filter(h1, 1, alea1);


% Graphe du signal filtré
figure('Name','Signal transmis avec le modulateur 1');
t1 = 0:Te:(N*Ns1-1)*Te; 
plot(t1,alea1_filtre);
xlabel('t en s');
ylabel('x1(t)');
title('Signal transmis x1 avec le modulateur 1');


% DSP 
S_alea1 = pwelch(alea1_filtre, [], [], p2, Fe, 'twosided');
figure('Name','Estimation de la DSP du signal avec le modulateur 1');
semilogy(fp2,S_alea1,'g');
xlabel('f en Hz');
ylabel('Amplitude');
title('Estimation de la DSP du signal transmis x1 avec le modulateur 1');

figure('Name','Comparaison des DSP théorique et estimée du signal avec le modulateur 1');
semilogy(fp2,S_alea1, 'g');
hold on
S_x1 = Ts1*sinc(Ts1*fp2).^2;                                            
semilogy(fp2,S_x1, 'r');
xlabel('f en Hz');
ylabel('Amplitude');
legend('DSP estimée','DSP théorique')
title('Comparaison des DSP théorique et estimée du signal transmis x1 avec le modulateur 1');


%% Modulateur 2


% Mapping : 00 -> -3 | 01 -> -1 | 10 -> 1 | 11 -> 3
trouve2 = alea(1:2:end) + alea(2:2:end);
ind00_2 = find(trouve2 == 0);
ind01_2 = find(trouve2 + alea(1:2:end) == 1);
ind10_2 = find(trouve2 + alea(1:2:end) == 2);
ind11_2 = find(trouve2 == 2);
alea2 = zeros(1,N/2);
alea2(ind00_2) = alea2(ind00_2) -3;
alea2(ind01_2) = alea2(ind01_2) -1;
alea2(ind10_2) = alea2(ind10_2) +1;
alea2(ind11_2) = alea2(ind11_2) +3;


% Suréchantillonnage
Rs2 = Rb/2;
Ts2 = 1/Rs2;
Ns2 = floor(Ts2/Te); % à modifier
alea2 = [ alea2 ; zeros(Ns2 -1,N/2) ];
alea2 = alea2(:);
alea2 = alea2';


% Filtre
h2 = ones(1, Ns2);
alea2_filtre = filter(h2, 1, alea2);


% Graphe du signal filtré
figure('Name','Signal transmis avec le modulateur 2');
t2 = 0:Te:(N*Ns2/2-1)*Te; 
plot(t2,alea2_filtre);
xlabel('t en s');
ylabel('x2(t)');
title('Signal transmis x2 avec le modulateur 2');


% DSP 
S_alea2 = pwelch(alea2_filtre, [], [], p2, Fe, 'twosided');
figure('Name','Estimation de la DSP du signal avec le modulateur 2');
semilogy(fp2,S_alea2, 'g');
xlabel('f en Hz');
ylabel('Amplitude');
title('Estimation de la DSP du signal transmis x2 avec le modulateur 2');

figure('Name','Comparaison des DSP théorique et estimée du signal avec le modulateur 2');
semilogy(fp2,S_alea2, 'g');
hold on
S_x2 = Ts2*sinc(Ts2*fp2).^2;                                            %% à revoir
S_x2 = ((1.5)^2)*S_x2;
semilogy(fp2, S_x2, 'r');
xlabel('f en Hz');
ylabel('Amplitude');
legend('DSP estimée','DSP théorique')
title('Comparaison des DSP théorique et estimée du signal transmis x2 avec le modulateur 2');


%% Modulateur 3


% alea3 = alea1;


% Filtre
h3 = [ ones(1, Ns1/2) -ones(1, Ns1/2 + mod(Ns1,2)) ];
alea3_filtre = filter(h3, 1, alea1);

% Graphe du signal filtré
figure('Name','Signal transmis avec le modulateur 3');
plot(t1,alea3_filtre);
xlabel('t en s');
ylabel('x3(t)');
title('Signal transmis x3 avec le modulateur 3');

% DSP 
S_alea3 = pwelch(alea3_filtre, [], [], p2, Fe, 'twosided');
figure('Name','Estimation de la DSP du signal avec le modulateur 3');
semilogy(fp2,S_alea3, 'g');
xlabel('f en Hz');
ylabel('Amplitude');
title('Estimation de la DSP du signal transmis x3 avec le modulateur 3');

figure('Name','Comparaison des DSP théorique et estimée du signal avec le modulateur 3');
semilogy(fp2,S_alea3, 'g');
hold on
S_x3 = Ts1*(sin(pi*Ts1*fp2/2).^4)./(pi*fp2*Ts1/2).^2;
semilogy(fp2,S_x3, 'r');
xlabel('f en Hz');
ylabel('Amplitude');
legend('DSP estimée','DSP théorique')
title('Comparaison des DSP théorique et estimée du signal transmis x3 avec le modulateur 3');


%% Modulateur 4


%alea4 = alea1;


% Filtre
alpha = 0.5;
h4 = rcosdesign(alpha, 8, Ns1);
alea4_filtre = filter(h4, 1, alea1);


% Graphe du signal filtré
figure('Name','Signal transmis avec le modulateur 1'); 
plot(t1,alea4_filtre);
xlabel('t en s');
ylabel('x4(t)');
title('Signal transmis x4 avec le modulateur 4');


% DSP 
S_alea4 = pwelch(alea4_filtre, [], [], p2, Fe, 'twosided');
figure('Name','Estimation de la DSP du signal avec le modulateur 4');
semilogy(fp2,S_alea4);
xlabel('f en Hz');
ylabel('Amplitude');
title('Estimation de la DSP du signal transmis x4 avec le modulateur 4');

% construction de la DSP théorique
f = linspace(0,Fe,p2);
f4 = [linspace(0, Fe/2, p2/2) linspace(-Fe/2, 0, p2/2)];
borne1 = (1 - alpha)/(2*Ts1);
S_x4 = 0.5*(1 + cos((pi*Ts1/alpha)*(abs(f4)-borne1)));
indice_b1p = find(f <= borne1);
indice_b1n = find(f >= (Fe - borne1));
S_x4(indice_b1p) = S_x4(indice_b1p) - S_x4(indice_b1p) + 1;
S_x4(indice_b1n) = S_x4(indice_b1n) - S_x4(indice_b1n) + 1;
borne2 = (1 + alpha)/(2*Ts1);
indice_b2p = find(f >= borne2, 1);
indice_b2n = find(f <= (Fe - borne2), 1, 'last');
S_x4(indice_b2p:1:indice_b2n) = S_x4(indice_b2p:1:indice_b2n) - S_x4(indice_b2p:1:indice_b2n);

figure('Name','Comparaison des DSP théorique et estimée du signal avec le modulateur 4');
semilogy(fp2,S_alea4, 'g');
hold on
semilogy(fp2, S_x4, 'r');
hold on
semilogy(fp2, S_x4*10^(-4));
xlabel('f en Hz');
ylabel('Amplitude');
legend('DSP estimée','DSP théorique', 'DSP théorique x10^-4')
title('Comparaison des DSP théorique et estimée du signal transmis x1 avec le modulateur 1');


%% Comparaison des modulateurs

figure('Name','Comparaison des DSP estimées pour chaque modulateur');
semilogy(fp2, S_alea1);
hold on
semilogy(fp2, S_alea2);
hold on
semilogy(fp2, S_alea3);
hold on
semilogy(fp2, S_alea4);
xlabel('f en Hz');
ylabel('Amplitude');
legend('DSP avec le modulateur 1','DSP avec le modulateur 2', 'DSP avec le modulateur 3', 'DSP avec le modulateur 4');
title('Comparaison des DSP estimées pour chaque modulateur');


figure('Name','Comparaison des DSP théoriques pour chaque modulateur échelle log');
semilogy(fp2, S_x1);
hold on
semilogy(fp2, S_x2);
hold on
semilogy(fp2, S_x3);
hold on
semilogy(fp2, S_x4);
xlabel('f en Hz');
ylabel('Amplitude');
legend('DSP avec le modulateur 1','DSP avec le modulateur 2', 'DSP avec le modulateur 3', 'DSP avec le modulateur 4');
title('Comparaison des DSP théoriques pour chaque modulateur en échelle semilogarithmique');


figure('Name','Comparaison des DSP théoriques pour chaque modulateur');
plot(fp2, S_x1);
hold on
plot(fp2, S_x2);
hold on
plot(fp2, S_x3);
hold on
plot(fp2, S_x4)
xlabel('f en Hz');
ylabel('Amplitude');
xlim([0 1.5*10^4]);
ylim([0 5*10^-4]);
legend('DSP avec le modulateur 1','DSP avec le modulateur 2', 'DSP avec le modulateur 3', 'DSP avec le modulateur 4');
title('Comparaison des DSP théoriques pour chaque modulateur');
