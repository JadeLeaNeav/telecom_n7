function [Eb_sur_N0_db_tab,tebs, tess] = q233(debut, nb, fin, x1, Ns, M, h1, alea, N, g_t0, symboles)

% constantes
n = length(x1); %nombre d'échantillons
Px = mean(abs(x1).^2); %puissance du signal



bruit = randn(1,n);
tebs = zeros(1,nb); %TEBs selon l'échelle
tess = zeros(1,nb); %TESs selon l'échelle


% échelle en db
Eb_sur_N0_db_tab = linspace(debut,fin,nb);




%création du bruit
for k= 1:nb
    Eb_sur_N0 = 10^(Eb_sur_N0_db_tab(k)/10);
    sigma_carre = Px*Ns / ( 2*log2(M)*Eb_sur_N0 );
    sigma = sqrt(sigma_carre);
    x = x1;
    bruit_k = sigma*bruit;
    x = x + bruit_k;
    z = filter(h1,1,x);
    z = z(Ns:Ns:end);
    d = zeros(1, length(z));
    for k2=1:length(z)    
        if z(k2) < -2*g_t0        
            d(k2) = -3;
        elseif z(k2) < 0        
            d(k2) = -1;
        elseif z(k2) < 2*g_t0
            d(k2) = 1;
        else
            d(k2) = 3;
        end
    end
    
    tess(k) = 2* length(find(symboles ~= d(1:N/2)))/N;
    f = reshape(de2bi((d+ 3)/2).',1,N);


    
    tebs(k) = length(find(alea ~= f(1:N)))/N;
    
    

end


end

