close all
clear all



% Constantes du TP
Fe = 24000; % fréquence d'échantillonnage Fe = 24 000 Hz
Te = 1/Fe; % période d'échantillonnage en s
Rb = 6000; % débit binaire Rb = 3 000 bits/s
Tb = 1/Rb; 
Ts = 1/Rb;
Ns = floor(Ts/Te); %Ns = Fe/Rb; % Rs = Rb
M = 2; % nombre de symboles possibles


% Nombre de bits
N = 10000; 

% échelle fréquentielle
p2 = 8192;
fp2 = linspace(0, Fe, p2);

% Génération d'une suite de bits
alea = randi([0,1],1,N);


% Mapping : 1 -> 1 | 0 -> -1
indices1 = find(alea == 0);
x = alea;
x(indices1) = x(indices1) - 1;


% Suréchantillonnage 
x = [ x ; zeros(Ns -1,N) ];
x = x(:);
x = x';

%% PARTIE 2

% Filtre de mise en forme
    
ordre1 = 2*Ns +1;
retard1 = Ns;
h1 = ones(1, Ns);
x1 = filter(h1, 1, [x zeros(1,retard1)]); %%pas nécessaire
xx = x1;   
  
    
% Canal de propagation

% null

% Bruit
Px = mean(abs(x1).^2);


%Test de valeur Eb/N0 -> meilleur diagramme de l'oeil quand Eb/N0 augmente
Eb_sur_N0 = 1; 

sigma_carre = Px*Ns / ( 2*log2(M)*Eb_sur_N0 );
sigma = sqrt(sigma_carre);
bruit = sigma*randn(1,length(x1));

% ajout du bruit
x1 = x1 + bruit;

%teb simulé
[Eb_sur_N0_db_tab,tebs] = q233(0, 17, 8, xx, Ns, M, h1, alea, N);

% Filtres de réception

% hr1 = h1;

z1 = filter(h1, 1, x1);

    % Modifier la ligne 59 pour visualiser le diagramme de l'oeil pour
    % différentes valeurs de Eb/N0
    
    %Figure 1
    figure('Name', 'Q2.3.1 : Diagramme de l oeil');
    z1_oeil = z1(Ns+1:end-Ns); % on enlève les Ns premiers et les Ns derniers échantillons
    plot(reshape(z1_oeil, Ns, length(z1_oeil) / Ns ));
    xlabel('en numéro d échantillon');
    ylabel('z1(t)');
    legend('Diagramme de l oeil du signal reçu z1');
    title('Chaîne de référence : Diagramme de l oeil du signal reçu z1');

% Echantillonnages 

z1_opt = z1(Ns:Ns:end);


% Histogramme

%figure();
%hist(z1_opt, 100);


% Décision

d1_opt = sign(z1_opt);


% Demapping

f1_opt = (d1_opt +1)/2;



% TEB

teb1_opt = length(find(alea ~= f1_opt(1:N)))/N;

    %TEB en fonction de Eb/N0
    
    %Figure 2
    figure('Name', 'Q2.3.2 : TEB simulé en fonction de Eb/N0');
    semilogy(Eb_sur_N0_db_tab, tebs);
    xlabel('Eb/N0');
    ylabel('TEB');
    legend('TEB simulé');
    title('Chaîne de référence : TEB simulé');
    
    %Figure 3
    TEB_tab = qfunc(sqrt(2*exp(log(10)*Eb_sur_N0_db_tab/10)));
    figure('Name', 'Q2.3.3 : TEB en fonction de Eb/N0');
    semilogy(Eb_sur_N0_db_tab, TEB_tab, Eb_sur_N0_db_tab, tebs);
    xlabel('Eb/N0');
    ylabel('TEB');
    legend('TEB théorique', 'TEB simulé');
    title('Chaîne de référence : compararaison du TEB simulé et du TEB théorique');
    
%% PARTIE 3.2

% hr1 = h1;
hr2 = [ ones(1,Ns/2) zeros(1,Ns/2) ];

z2 = filter(hr2, 1, xx);

   %Figure 4
    figure('Name', 'Q3.1.1 : Diagramme de l oeil');
    z2_oeil = z2(Ns+1:end-Ns); % on enlève les Ns premiers et les Ns derniers échantillons
    plot(reshape(z2_oeil, Ns, length(z2_oeil) / Ns ));
    xlabel('en numéro d échantillon');
    ylabel('z2(t)');
    legend('Diagramme de l oeil du signal reçu');
    title('Première chaîne à étudier : Diagramme de l oeil du signal reçu');
    % n0 appartient à [2;4]

% Echantillonnages 

z2_opt = z2(3:Ns:end); %Ns = 4


% Décision

d2_opt = sign(z2_opt);


% Demapping

f2_opt = (d2_opt +1)/2;



% TEB

teb2_opt = length(find(alea ~= f2_opt(1:N)))/N;

%% PARTIE 3.3


%teb simulé
[Eb_sur_N0_db_tab,tebs2] = q233(0, 17, 8, xx, Ns, M, hr2, alea, N);

%Figure 5
figure('Name', 'Q3.3.2 : TEB simulé en fontion de Eb/N0 db')
semilogy(Eb_sur_N0_db_tab, tebs2);  
xlabel('Eb/N0');
ylabel('TEB');
title('Première chaîne à étudier : TEB simulé');

%TEB en fonction de Eb/N0 théorique
    
    TEB_tab2 = qfunc(sqrt(exp(log(10)*Eb_sur_N0_db_tab/10)));
    
    %Figure 6
    figure('Name', 'Q3.3.3 : TEB en fonction de Eb/N0')
    semilogy(Eb_sur_N0_db_tab, TEB_tab2);
    hold on
    semilogy(Eb_sur_N0_db_tab, tebs2);
    xlabel('Eb/N0');
    ylabel('TEB');
    legend('TEB théorique', 'TEB simulé');
    title('Première chaîne à étudier : compararaison du TEB simulé et du TEB théorique');
    
    %Figure 7
    figure('Name', 'Q3.3.4 : Comparaison des TEB chaîne de référence et première chaîne étudiée')
    semilogy(Eb_sur_N0_db_tab, TEB_tab);
    hold on
    semilogy(Eb_sur_N0_db_tab, TEB_tab2);
    xlabel('Eb/N0');
    ylabel('TEB');
    legend('TEB de la chaîne de référence', 'TEB de la première chaîne à étudier');
    title('Première chaîne à étudier : compararaison du TEB théorique à celui de la chaîne de référence');

    %% PARTIE 4

    Ts = 2*Tb;
    Ns = floor(Ts/Te); %Ns = Fe/Rb; % Rs = Rb ; Ns= 8
    M = 4; % nombre de symboles possibles
    
    %Mapping 
    symboles = (2*bi2de(reshape(alea,2,N/2).')-3).';
    mapping = symboles;
    
    % Suréchantillonnage 
    symboles = [ symboles ; zeros(Ns -1,N/2) ];
    symboles = symboles(:);
    symboles = symboles';
    
    
    
    %Filtre de mise en forme
    h3 = ones(1, Ns);
    x3 = filter(h3, 1, symboles);
    
    %canal de prop = null
    
    %filtre de réception
    z3 = filter(h3, 1, x3);

   %Figure 8
    figure('Name', 'Q4.2.1 : Diagramme de l oeil');
    z3_oeil = z3(Ns+1:end-Ns); % on enlève les Ns premiers et les Ns derniers échantillons
    plot(reshape(z3_oeil, Ns, length(z3_oeil) / Ns ));
    xlabel('en numéro d échantillon');
    ylabel('z3(t)');
    legend('Diagramme de l oeil du signal reçu z3');
    title('Deuxieme chaîne à étudier : Diagramme de l oeil du signal reçu');
    
% Echantillonnages 

z3_opt = z3(Ns:Ns:end);

% Décision

g_t0 = 8;
d3_opt = zeros(1, length(z3_opt));

for k=1:length(z3_opt)
    if z3_opt(k) < -2*g_t0
        d3_opt(k) = -3;
    elseif z3_opt(k) < 0
        d3_opt(k) = -1;
    elseif z3_opt(k) < 2*g_t0
        d3_opt(k) = 1;
    else
        d3_opt(k) = 3;
    end
end




% Demapping


f3_opt = reshape(de2bi((d3_opt+ 3)/2).',1,N);


% TEB

teb3_opt = length(find(alea ~= f3_opt(1:N)))/N;

% COmp TEBS

[Eb_sur_N0_db_tab,tebs3, tes] = q431(0, 17, 8, x3, Ns, M, h3, alea, N, g_t0, mapping);

 

TES = 1.5 * qfunc(sqrt(0.8 * exp(log(10)*Eb_sur_N0_db_tab/10)));

    %Figure 9
    figure('Name', 'Q4.3.1 : TES simulé en fonction de Eb/N0')
    semilogy(Eb_sur_N0_db_tab, tes);
    xlabel('Eb/N0');
    ylabel('TES');
    legend('TES simulé');
    title('Deuxième chaîne à étudier : TES simulé en fonction de Eb/N0');

    %Figure 10
    figure('Name', 'Q4.3.2 : Comparaison des TES simulé et théorique')
    semilogy(Eb_sur_N0_db_tab, TES);
    hold on
    semilogy(Eb_sur_N0_db_tab, tes);
    xlabel('Eb/N0');
    ylabel('TES');
    legend('TES théorique', 'TES simulé');
    title('Deuxième chaîne à étudier : compararaison des TES théorique et simulé');
    
    %Figure 11
    figure('Name', 'Q4.3.3 : TEB simulé en fonction de Eb/N0')
    semilogy(Eb_sur_N0_db_tab, tebs3);
    xlabel('Eb/N0');
    ylabel('TEB');
    legend('TEB simulé');
    title('Deuxième chaîne à étudier : TEB simulé en fonction de Eb/N0');  
    
    %Figure 12
    figure('Name','Q4.3.4 ; Comparaison des TEBs théorique et simulé')
    semilogy(Eb_sur_N0_db_tab, TES/2);
    hold on
    semilogy(Eb_sur_N0_db_tab, tebs3);
    xlabel('Eb/N0');
    ylabel('TEB');
    legend('TEB théorique', 'TEB simulé');
    title('Deuxième chaîne à étudier : compararaison des TEB théorique et simulé');
    %pas de mapping de gray
   
    figure('Name','Q4.3.5 : Comparaison des TEB chaîne de référence et deuxième chaîne étudiée')
    semilogy(Eb_sur_N0_db_tab, TEB_tab);
    hold on
    semilogy(Eb_sur_N0_db_tab, TES/2);
    hold on
    semilogy(Eb_sur_N0_db_tab, tebs3);
    xlabel('Eb/N0');
    ylabel('TEB');
    legend('TEB de la chaîne de référence', 'TEB théorique de la deuxième chaîne à étudier', 'TEB simulé de la deuxième chaîne à étudier');
    title('Deuxième chaîne à étudier : compararaison des TEBs simulé et théorique au TEB théorique de la chaîne de référence');
    % pour une même énergie, plus de niveaux donc plus mauvais
