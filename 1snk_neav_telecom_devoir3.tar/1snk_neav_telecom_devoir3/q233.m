function [Eb_sur_N0_db_tab,tebs] = q233(debut, nb, fin, x1, Ns, M, h1, alea, N)

% constantes
n = length(x1); %nombre d'échantillons
Px = mean(abs(x1).^2); %puissance du signal



bruit = randn(1,n);
tebs = nan(1,nb); %TEBs selon l'échelle

% échelle en db
Eb_sur_N0_db_tab = linspace(debut,fin,nb);




%création du bruit
for k= 1:nb
    Eb_sur_N0 = 10^(Eb_sur_N0_db_tab(k)/10);
    sigma_carre = Px*Ns / ( 2*log2(M)*Eb_sur_N0 );
    sigma = sqrt(sigma_carre);
    x = x1;
    bruit_k = sigma*bruit;
    x = x + bruit_k;
    z = filter(h1,1,x);
    z_ech = z(Ns:Ns:end);
    z_ech = sign(z_ech);
    z_ech = (z_ech+1)/2;
    tebs(k) = length(find(alea ~= z_ech(1:N)))/N;
end


end

